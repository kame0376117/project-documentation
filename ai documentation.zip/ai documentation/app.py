from flask import Flask, render_template, request
from pathlib import Path
from zipfile import ZipFile, BadZipFile

app = Flask(__name__)

UPLOAD_FOLDER = Path("uploads")
UPLOAD_FOLDER.mkdir(exist_ok=True)

app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/generate", methods=["POST"])
def generate():
    uploaded_file = request.files.get("project")

    if not uploaded_file or not uploaded_file.filename:
        return "Please select a ZIP file.", 400

    if not uploaded_file.filename.lower().endswith(".zip"):
        return "Please upload a ZIP file only.", 400

    zip_path = UPLOAD_FOLDER / "project.zip"
    uploaded_file.save(zip_path)

    try:
        with ZipFile(zip_path, "r") as archive:
            files = [
                name for name in archive.namelist()
                if not name.endswith("/")
                and not name.startswith("/")
                and ".." not in Path(name).parts
            ]

        if not files:
            return "The ZIP file contains no usable files.", 400

        file_list = "\n".join(f"- {name}" for name in files[:100])

        return f"""
        <h1>Project Analysis Completed!</h1>
        <h2>Files found in your project</h2>
        <pre>{file_list}</pre>
        <a href="/">Go Back</a>
        """

    except BadZipFile:
        return "Invalid ZIP file. Please upload a valid ZIP.", 400


if __name__ == "__main__":
    app.run(debug=True)