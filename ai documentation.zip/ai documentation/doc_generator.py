
def generate_documentation(project_info):
    documentation = f"""
# Software Project Documentation

## Project Analysis

{project_info}
"""
    return documentation
